
let texto=prompt("Escriba la palabra a buscar");

if(texto){
    window.find(texto);
}